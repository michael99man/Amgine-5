package main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ChatPanel extends JPanel {
    private User user;
    private Chatroom chat;
    private Box box;
    
    private static final long serialVersionUID = -3466616916555224742L;

    public ChatPanel(User u, Chatroom chat){
        user = u;
        this.chat = chat;
        
        setLayout(new BorderLayout());
        setMinimumSize(new Dimension(300, 300));

        //box holds all the messages!
        box = Box.createVerticalBox();
        box.setSize(getSize());
        
        //struts + glue http://www.javaworld.com/article/2071317/getting-to-know-boxlayout.html
        JLabel title = new JLabel(user.name);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JTextField textField = new JTextField();
        textField.setMaximumSize(textField.getPreferredSize());
        textField.addKeyListener(new KeyListener(){
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    //send the message!
                    chat.sendMessage(user, textField.getText());
                    textField.setText("");
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }});
        
        //box.add(label);
        //box.add(textField);
        
        add(box, BorderLayout.CENTER);
        add(title, BorderLayout.NORTH);
        add(textField, BorderLayout.SOUTH);
        user.pane = this;
        System.out.println("Initialized JPanel for: " + user);
    }
    
    //adds the new message to the display
    public void addMessage(Message m){
        JLabel label = new JLabel(m.sender.name + ": " + m.plaintext);
        box.add(label);
        revalidate();
        repaint();
    }
}
